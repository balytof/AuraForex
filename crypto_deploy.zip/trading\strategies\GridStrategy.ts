import { BaseStrategy } from "./BaseStrategy";

export class GridStrategy extends BaseStrategy {
  private levels: number[] = [];
  public activeOrders: Map<number, string> = new Map();

  constructor(config: any, exchange: any) {
    super(config, exchange);
  }

  async execute() {
    const { upper_limit, lower_limit, grid_count } = this.config;
    const step = (upper_limit - lower_limit) / grid_count;

    for (let i = 0; i <= grid_count; i++) {
      this.levels.push(lower_limit + i * step);
    }

    await this.placeInitialOrders();
  }

  async placeInitialOrders() {
    const ticker = await this.exchange.fetchTicker(this.symbol);
    const price = ticker.last;

    for (const level of this.levels) {
      let order;

      if (level < price) {
        order = await this.exchange.createLimitBuyOrder(
          this.symbol,
          this.config.amount,
          level
        );
      } else {
        order = await this.exchange.createLimitSellOrder(
          this.symbol,
          this.config.amount,
          level
        );
      }

      if (order && order.id !== 'skipped' && order.amount > 0) {
        this.activeOrders.set(level, order.id);
      }
    }
  }

  async onTick() {
    const ticker = await this.exchange.fetchTicker(this.symbol);
    const currentPrice = ticker.last;

    for (const [price, orderId] of this.activeOrders.entries()) {
      const order = await this.exchange.fetchOrder(orderId, this.symbol);

      if (order && order.status === "closed") {
        this.activeOrders.delete(price);

        const interval =
          (this.config.upper_limit - this.config.lower_limit) /
          this.config.grid_count;

        const newPrice =
          price < currentPrice ? price + interval : price - interval;

        const side = price < currentPrice ? "sell" : "buy";

        let newOrder;

        if (side === "buy") {
          newOrder = await this.exchange.createLimitBuyOrder(
            this.symbol,
            this.config.amount,
            newPrice
          );
        } else {
          newOrder = await this.exchange.createLimitSellOrder(
            this.symbol,
            this.config.amount,
            newPrice
          );
        }

        if (newOrder && newOrder.id !== 'skipped' && newOrder.amount > 0) {
          this.activeOrders.set(newPrice, newOrder.id);
        }
      }
    }
  }
}
