export class ExecutionEngine {
  constructor(private exchange: any) {}

  async safeOrder(type: string, symbol: string, amount: number, price?: number) {
    try {
      if (type === "buy") {
        return price
          ? await this.exchange.createLimitBuyOrder(symbol, amount, price)
          : await this.exchange.createMarketBuyOrder(symbol, amount);
      }

      if (type === "sell") {
        return price
          ? await this.exchange.createLimitSellOrder(symbol, amount, price)
          : await this.exchange.createMarketSellOrder(symbol, amount);
      }
    } catch (e) {
      console.error("Order error:", e);
    }
  }
}
