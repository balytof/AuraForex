import { BaseStrategy } from "./BaseStrategy";

export class AIAdaptiveStrategy extends BaseStrategy {
  // ─── State ──────────────────────────────────────────────────────────────
  public prices: number[] = [];
  public volumes: number[] = [];

  // ─── Persistent Indicator State ──────────────────────────────────────────
  public emaShortState: number | null = null;
  public emaLongState: number | null = null;

  // ─── Position State ──────────────────────────────────────────────────────
  public position: "NONE" | "LONG" | "SHORT" = "NONE";
  public entryPrice: number = 0;
  public highestPrice: number = 0;   // for long trailing stop
  public lowestPrice: number = Infinity; // for short trailing stop
  public currentAmount: number = 0;  // actual amount bought/shorted

  // ─── Cooldown Control ────────────────────────────────────────────────────
  public cooldownTicks: number = 0;

  // ─── Performance Stats ───────────────────────────────────────────────────
  public totalTrades: number = 0;
  public winningTrades: number = 0;
  public totalPnL: number = 0;
  public peakBalance: number = 0;
  public maxDrawdown: number = 0;
  public initialBalance: number = 0;

  // ─── Configuration Constants ─────────────────────────────────────────────
  private readonly RISK_PERCENT = 0.02;      // 2% of balance per trade
  private readonly STOP_LOSS_PCT = 0.015;    // 1.5% fixed stop loss
  private readonly TAKE_PROFIT_PCT = 0.03;   // 3% fixed take profit
  private readonly TRAILING_STOP_PCT = 0.01; // 1% trailing stop
  private readonly COOLDOWN_PERIOD = 5;      // Ticks to wait after a trade
  private readonly EMA_SHORT = 9;
  private readonly EMA_LONG = 21;
  private readonly RSI_PERIOD = 14;
  private readonly VOL_MA_PERIOD = 20;

  async execute() {
    console.log(`[AI Adaptive] Initializing strategy for ${this.symbol}`);
    console.log(`[AI Adaptive] Parameters: SL=${this.STOP_LOSS_PCT * 100}%, TP=${this.TAKE_PROFIT_PCT * 100}%, TS=${this.TRAILING_STOP_PCT * 100}%`);
    
    try {
      const balance = await this.exchange.fetchBalance();
      this.initialBalance = balance.total?.USDT || 0;
      this.peakBalance = this.initialBalance;
      console.log(`[AI Adaptive] Initial Balance: ${this.initialBalance.toFixed(2)} USDT`);
    } catch (error) {
      console.error("[AI Adaptive] Failed to fetch initial balance:", error);
    }
  }

  async onTick() {
    try {
      const ticker = await this.exchange.fetchTicker(this.symbol);
      const price = ticker.last;
      const volume = ticker.quoteVolume || ticker.baseVolume * price;

      // Update history (sliding window max 200)
      this.prices.push(price);
      this.volumes.push(volume);
      if (this.prices.length > 200) {
        this.prices.shift();
        this.volumes.shift();
      }

      // Need enough data for indicators
      if (this.prices.length < this.EMA_LONG) return;

      // Calculate Indicators
      const emaShort = this.calculateEMA(price, this.EMA_SHORT, "short");
      const emaLong = this.calculateEMA(price, this.EMA_LONG, "long");
      const rsi = this.calculateRSI(this.RSI_PERIOD);
      const atr = this.calculateATR(14);
      const volMA = this.calculateSMA(this.volumes, this.VOL_MA_PERIOD);
      
      const momentum = price - this.prices[this.prices.length - 5];
      const volumeIsStrong = volume > volMA * 1.2;

      // ─── Position Management ───────────────────────────────────────────────
      if (this.position === "LONG") {
        // Update trailing stop
        if (price > this.highestPrice) {
          this.highestPrice = price;
        }

        const pnlPct = (price - this.entryPrice) / this.entryPrice;
        const trailingStopPrice = this.highestPrice * (1 - this.TRAILING_STOP_PCT);

        // Exit Conditions
        const hitStopLoss = pnlPct <= -this.STOP_LOSS_PCT;
        const hitTakeProfit = pnlPct >= this.TAKE_PROFIT_PCT;
        const hitTrailingStop = price <= trailingStopPrice;
        const trendReversal = emaShort < emaLong;

        if (hitStopLoss || hitTakeProfit || hitTrailingStop || trendReversal) {
          let reason = "";
          if (hitStopLoss) reason = "Stop Loss";
          else if (hitTakeProfit) reason = "Take Profit";
          else if (hitTrailingStop) reason = "Trailing Stop";
          else if (trendReversal) reason = "Trend Reversal";

          await this.sell(price, reason);
        }
      } 
      else if (this.position === "SHORT") {
        // Update trailing stop
        if (price < this.lowestPrice) {
          this.lowestPrice = price;
        }

        const pnlPct = (this.entryPrice - price) / this.entryPrice;
        const trailingStopPrice = this.lowestPrice * (1 + this.TRAILING_STOP_PCT);

        // Exit Conditions
        const hitStopLoss = pnlPct <= -this.STOP_LOSS_PCT;
        const hitTakeProfit = pnlPct >= this.TAKE_PROFIT_PCT;
        const hitTrailingStop = price >= trailingStopPrice;
        const trendReversal = emaShort > emaLong;

        if (hitStopLoss || hitTakeProfit || hitTrailingStop || trendReversal) {
          let reason = "";
          if (hitStopLoss) reason = "Stop Loss";
          else if (hitTakeProfit) reason = "Take Profit";
          else if (hitTrailingStop) reason = "Trailing Stop";
          else if (trendReversal) reason = "Trend Reversal";

          await this.closeShort(price, reason);
        }
      }
      // ─── Entry Logic ──────────────────────────────────────────────────────
      else if (this.cooldownTicks === 0) {
        const emaCrossover = emaShort > emaLong;
        const emaCrossunder = emaShort < emaLong;
        const rsiNotOverbought = rsi < 70;
        const rsiBullish = rsi > 50;
        const rsiNotOversold = rsi > 30;
        const rsiBearish = rsi < 50;
        const momentumPositive = momentum > 0;
        const momentumNegative = momentum < 0;

        if (emaCrossover && rsiNotOverbought && rsiBullish && momentumPositive && volumeIsStrong) {
          await this.buy(price);
        } else if (emaCrossunder && rsiNotOversold && rsiBearish && momentumNegative && volumeIsStrong) {
          await this.short(price);
        }
      }

      // Handle cooldown
      if (this.cooldownTicks > 0) {
        this.cooldownTicks--;
      }

    } catch (error) {
      console.error(`[AI Adaptive] Tick Error:`, error);
    }
  }

  // ─── Helper Methods ──────────────────────────────────────────────────────

  private async buy(price: number) {
    try {
      const balance = await this.exchange.fetchBalance();
      const usdtBalance = balance.free?.USDT || 0;
      
      if (usdtBalance < 10) {
        console.log("[AI Adaptive] Insufficient USDT balance to buy.");
        return;
      }

      // Risk-based sizing (use 2% of balance or full amount if small)
      const riskAmount = usdtBalance * this.RISK_PERCENT;
      const amountToSpend = Math.max(riskAmount, Math.min(usdtBalance, this.config.amount * price || 50));
      const amount = amountToSpend / price;

      console.log(`[AI Adaptive] BUY Signal | Price: ${price} | Amount: ${amount.toFixed(6)}`);
      
      const order = await this.exchange.createMarketBuyOrder(this.symbol, amount);
      
      if (order.amount === 0) {
        console.warn("[AI Adaptive] Buy order resulted in 0 amount (below notional or no balance). Skipping entry.");
        return;
      }
      
      this.position = "LONG";
      this.entryPrice = price;
      this.highestPrice = price;
      this.currentAmount = order.amount;
      this.cooldownTicks = 0; // Reset cooldown on entry
      
    } catch (error) {
      console.error("[AI Adaptive] Buy Order Failed:", error);
    }
  }

  private async sell(price: number, reason: string) {
    try {
      console.log(`[AI Adaptive] SELL Signal (${reason}) | Price: ${price}`);
      
      // FIX: Spot Fee Bug. A exchange retira a taxa da moeda base na compra.
      // this.currentAmount tem o valor bruto, mas na carteira temos um pouco menos.
      const baseCurrency = this.symbol.split('/')[0] || this.symbol.replace('USDT', '');
      const balance = await this.exchange.fetchBalance();
      const availableBase = balance.free?.[baseCurrency] || 0;
      
      // Vende o que temos disponível na carteira (descontando as taxas) ou o limite do amount
      const amountToSell = Math.min(this.currentAmount, availableBase);
      
      if (amountToSell <= 0) {
        console.warn("[AI Adaptive] Sem saldo disponível na carteira para vender. Reset a forçar.");
        this.position = "NONE";
        this.entryPrice = 0;
        this.highestPrice = 0;
        this.currentAmount = 0;
        this.cooldownTicks = this.COOLDOWN_PERIOD;
        return;
      }
      
      const order = await this.exchange.createMarketSellOrder(this.symbol, amountToSell);
      const actualAmount = order.amount;
      
      if (actualAmount === 0) {
        console.warn("[AI Adaptive] Sell order resulted in 0 amount. Manually checking balance to decide position reset.");
        const checkBalance = await this.exchange.fetchBalance();
        const checkBase = checkBalance.free?.[baseCurrency] || 0;
        if (checkBase < (this.currentAmount * 0.1)) { // Se tivermos menos de 10% da quantidade, assumimos que foi vendido
          this.position = "NONE";
          this.entryPrice = 0;
          this.highestPrice = 0;
          this.currentAmount = 0;
          this.cooldownTicks = this.COOLDOWN_PERIOD;
        }
        return;
      }
      
      const pnl = (price - this.entryPrice) * actualAmount;
      const pnlPct = ((price - this.entryPrice) / this.entryPrice) * 100;
      
      this.totalTrades++;
      if (pnl > 0) this.winningTrades++;
      this.totalPnL += pnl;

      // Update stats
      const currentBalance = this.initialBalance + this.totalPnL;
      if (currentBalance > this.peakBalance) {
        this.peakBalance = currentBalance;
      }
      const drawdown = ((this.peakBalance - currentBalance) / this.peakBalance) * 100;
      if (drawdown > this.maxDrawdown) {
        this.maxDrawdown = drawdown;
      }

      console.log(`[AI Adaptive] Trade Closed | PnL: ${pnl.toFixed(2)} USDT (${pnlPct.toFixed(2)}%)`);
      console.log(`[AI Adaptive] Stats | Win Rate: ${((this.winningTrades / this.totalTrades) * 100).toFixed(1)}% | Max DD: ${this.maxDrawdown.toFixed(2)}%`);

      this.position = "NONE";
      this.entryPrice = 0;
      this.highestPrice = 0;
      this.currentAmount = 0;
      this.cooldownTicks = this.COOLDOWN_PERIOD;
      
    } catch (error: any) {
      console.error("[AI Adaptive] Sell Order Failed:", error);
      // If we fail because of insufficient balance, it means the position is already gone or out of sync.
      // We should reset the state to avoid being stuck in a loop.
      if (error.message.includes("Insufficient balance") || error.message.includes("insufficient balance")) {
        console.warn("[AI Adaptive] Insufficient balance on exchange. Resetting position state assuming manual liquidation.");
        this.position = "NONE";
        this.entryPrice = 0;
        this.highestPrice = 0;
        this.currentAmount = 0;
        this.cooldownTicks = this.COOLDOWN_PERIOD;
      } else {
        console.warn("[AI Adaptive] Sell order failed but balance might still exist. Keeping position LONG to try again.");
      }
    }
  }

  private async short(price: number) {
    try {
      const balance = await this.exchange.fetchBalance();
      const usdtBalance = balance.free?.USDT || 0;
      
      if (usdtBalance < 10) {
        console.log("[AI Adaptive] Insufficient USDT balance to short.");
        return;
      }

      const riskAmount = usdtBalance * this.RISK_PERCENT;
      const amountToSpend = Math.max(riskAmount, Math.min(usdtBalance, this.config.amount * price || 50));
      const amount = amountToSpend / price;

      console.log(`[AI Adaptive] SHORT Signal | Price: ${price} | Amount: ${amount.toFixed(6)}`);
      
      const order = await this.exchange.createMarketSellOrder(this.symbol, amount);
      
      if (order.amount === 0) {
        console.warn("[AI Adaptive] Short order resulted in 0 amount. Skipping entry.");
        return;
      }
      
      this.position = "SHORT";
      this.entryPrice = price;
      this.lowestPrice = price;
      this.currentAmount = order.amount;
      this.cooldownTicks = 0;
      
    } catch (error) {
      console.error("[AI Adaptive] Short Order Failed:", error);
    }
  }

  private async closeShort(price: number, reason: string) {
    try {
      console.log(`[AI Adaptive] CLOSE SHORT Signal (${reason}) | Price: ${price}`);
      
      if (this.currentAmount <= 0) {
        this.position = "NONE";
        return;
      }
      
      const order = await this.exchange.createMarketBuyOrder(this.symbol, this.currentAmount);
      const actualAmount = order.amount;
      
      const pnl = (this.entryPrice - price) * actualAmount;
      const pnlPct = ((this.entryPrice - price) / this.entryPrice) * 100;
      
      this.totalTrades++;
      if (pnl > 0) this.winningTrades++;
      this.totalPnL += pnl;

      const currentBalance = this.initialBalance + this.totalPnL;
      if (currentBalance > this.peakBalance) this.peakBalance = currentBalance;
      
      const drawdown = ((this.peakBalance - currentBalance) / this.peakBalance) * 100;
      if (drawdown > this.maxDrawdown) this.maxDrawdown = drawdown;

      console.log(`[AI Adaptive] Trade Closed | PnL: ${pnl.toFixed(2)} USDT (${pnlPct.toFixed(2)}%)`);
      console.log(`[AI Adaptive] Stats | Win Rate: ${((this.winningTrades / this.totalTrades) * 100).toFixed(1)}% | Max DD: ${this.maxDrawdown.toFixed(2)}%`);

      this.position = "NONE";
      this.entryPrice = 0;
      this.lowestPrice = Infinity;
      this.currentAmount = 0;
      this.cooldownTicks = this.COOLDOWN_PERIOD;
      
    } catch (error: any) {
      console.error("[AI Adaptive] Close Short Failed:", error);
      this.position = "NONE";
      this.currentAmount = 0;
      this.cooldownTicks = this.COOLDOWN_PERIOD;
    }
  }

  private calculateEMA(currentPrice: number, period: number, type: "short" | "long"): number {
    const k = 2 / (period + 1);
    let state = type === "short" ? this.emaShortState : this.emaLongState;

    if (state === null) {
      // Initialize with SMA
      const slice = this.prices.slice(-period);
      state = slice.reduce((a, b) => a + b, 0) / slice.length;
    } else {
      state = currentPrice * k + state * (1 - k);
    }

    if (type === "short") this.emaShortState = state;
    else this.emaLongState = state;

    return state;
  }

  private calculateRSI(period: number): number {
    if (this.prices.length <= period) return 50;

    let gains = 0;
    let losses = 0;

    for (let i = this.prices.length - period; i < this.prices.length; i++) {
      const diff = this.prices[i] - this.prices[i - 1];
      if (diff >= 0) gains += diff;
      else losses -= diff;
    }

    if (losses === 0) return 100;
    const rs = (gains / period) / (losses / period);
    return 100 - (100 / (1 + rs));
  }

  private calculateATR(period: number): number {
    if (this.prices.length <= period) return 0;
    
    let sum = 0;
    for (let i = this.prices.length - period; i < this.prices.length; i++) {
      sum += Math.abs(this.prices[i] - this.prices[i - 1]);
    }
    return sum / period;
  }

  private calculateSMA(data: number[], period: number): number {
    const slice = data.slice(-period);
    if (slice.length === 0) return 0;
    return slice.reduce((a, b) => a + b, 0) / slice.length;
  }
}
