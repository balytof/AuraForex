/**
 * ArbitrageStrategy — Arbitragem entre duas exchanges
 *
 * Conceito: comprar onde está mais barato, vender onde está mais caro,
 * capturando o spread líquido (depois de fees e slippage).
 *
 * Correções sobre o original:
 *  - Threshold dinâmico baseado em fees reais + slippage + lucro mínimo
 *  - Usa orderbook bid/ask em vez de ticker.last (preço executável real)
 *  - Mutex de execução (evita ciclos paralelos)
 *  - Verificação de saldo em ambas as exchanges antes de executar
 *  - Try/catch completo com recuperação de leg falhada
 *  - Direção bidirecional: ex1<ex2 OU ex2<ex1
 *  - Logging com P&L real por ciclo e estatísticas acumuladas
 */
export class ArbitrageStrategy {

  // ─── Mutex de execução ────────────────────────────────────────────────────
  public isExecuting: boolean = false;

  // ─── Estatísticas ─────────────────────────────────────────────────────────
  public totalTrades: number = 0;
  public winTrades: number = 0;
  public totalNetPnl: number = 0;

  // ─── Config com defaults ──────────────────────────────────────────────────

  /** Fee taker da exchange 1 (ex: Binance = 0.001) */
  private readonly FEE1: number = this.config.fee1 ?? 0.001;

  /** Fee taker da exchange 2 (ex: Kraken = 0.0026) */
  private readonly FEE2: number = this.config.fee2 ?? 0.001;

  /** Slippage estimado por leg (market orders) */
  private readonly SLIPPAGE_BUFFER: number = this.config.slippage_buffer ?? 0.0005;

  /** Lucro líquido mínimo exigido (acima de fees + slippage) */
  private readonly MIN_PROFIT_PCT: number = this.config.min_profit_pct ?? 0.001; // 0.1%

  /** Threshold total mínimo: fees + slippage + lucro mínimo */
  private get MIN_SPREAD(): number {
    return this.FEE1 + this.FEE2 + (this.SLIPPAGE_BUFFER * 2) + this.MIN_PROFIT_PCT;
  }

  /** % do saldo usado por operação */
  private readonly RISK_PCT: number = this.config.risk_pct ?? 0.05; // 5%

  /** Máximo de tentativas de recuperação numa leg falhada */
  private readonly MAX_RECOVERY_ATTEMPTS: number = 3;

  constructor(
    private ex1: any,
    private ex2: any,
    private config: any
  ) {}

  async execute() {
    console.log("=== ArbitrageStrategy started ===");
    console.log(`Symbol       : ${this.config.symbol}`);
    console.log(`Fee ex1      : ${(this.FEE1 * 100).toFixed(3)}%`);
    console.log(`Fee ex2      : ${(this.FEE2 * 100).toFixed(3)}%`);
    console.log(`Slippage buf : ${(this.SLIPPAGE_BUFFER * 100).toFixed(3)}% per leg`);
    console.log(`Min profit   : ${(this.MIN_PROFIT_PCT * 100).toFixed(3)}%`);
    console.log(`Min spread   : ${(this.MIN_SPREAD * 100).toFixed(3)}% (total threshold)`);
    console.log(`Risk/trade   : ${(this.RISK_PCT * 100).toFixed(1)}% of balance`);
  }

  async onTick() {
    // ─── Mutex: não iniciar novo ciclo se um está a decorrer ──────────────
    if (this.isExecuting) return;

    try {
      // ─── 1. Fetch orderbooks (bid/ask reais, não last) ─────────────────
      const [ob1, ob2] = await Promise.all([
        this.ex1.fetchOrderBook(this.config.symbol, 1),
        this.ex2.fetchOrderBook(this.config.symbol, 1),
      ]);

      // Preço real de execução para cada direcção
      const ask1 = ob1.asks?.[0]?.[0]; // preço a que compramos em ex1
      const bid1 = ob1.bids?.[0]?.[0]; // preço a que vendemos em ex1
      const ask2 = ob2.asks?.[0]?.[0]; // preço a que compramos em ex2
      const bid2 = ob2.bids?.[0]?.[0]; // preço a que vendemos em ex2

      if (!ask1 || !bid1 || !ask2 || !bid2) {
        console.warn("[TICK] Orderbook incompleto, a saltar.");
        return;
      }

      // ─── 2. Calcular spreads nas duas direcções ─────────────────────────
      // Direcção A: comprar ex1, vender ex2
      const spreadA = (bid2 - ask1) / ask1;

      // Direcção B: comprar ex2, vender ex1
      const spreadB = (bid1 - ask2) / ask2;

      // ─── 3. Executar direcção mais lucrativa se acima do threshold ──────
      if (spreadA >= this.MIN_SPREAD) {
        this.isExecuting = true;
        console.log(
          `[SIGNAL A] Buy ex1 @ ${ask1} | Sell ex2 @ ${bid2} | ` +
          `Gross spread: ${(spreadA * 100).toFixed(4)}% | ` +
          `Net est.: ${((spreadA - this.FEE1 - this.FEE2) * 100).toFixed(4)}%`
        );
        await this.executeArbitrage("A", ask1, bid2);

      } else if (spreadB >= this.MIN_SPREAD) {
        this.isExecuting = true;
        console.log(
          `[SIGNAL B] Buy ex2 @ ${ask2} | Sell ex1 @ ${bid1} | ` +
          `Gross spread: ${(spreadB * 100).toFixed(4)}% | ` +
          `Net est.: ${((spreadB - this.FEE1 - this.FEE2) * 100).toFixed(4)}%`
        );
        await this.executeArbitrage("B", ask2, bid1);
      }

    } catch (err: any) {
      console.error(`[TICK ERROR] ${err?.message ?? err}`);
    } finally {
      this.isExecuting = false;
    }
  }

  // ─── EXECUÇÃO DA ARBITRAGEM ───────────────────────────────────────────────

  /**
   * @param direction "A" = compra ex1 / vende ex2 | "B" = compra ex2 / vende ex1
   * @param buyPrice  preço esperado de compra (ask)
   * @param sellPrice preço esperado de venda (bid)
   */
  private async executeArbitrage(
    direction: "A" | "B",
    buyPrice: number,
    sellPrice: number
  ) {
    const buyEx  = direction === "A" ? this.ex1 : this.ex2;
    const sellEx = direction === "A" ? this.ex2 : this.ex1;
    const buyExName  = direction === "A" ? "ex1" : "ex2";
    const sellExName = direction === "A" ? "ex2" : "ex1";

    try {
      // ─── Verificar saldo antes de executar ────────────────────────────
      const amount = await this.calcAmount(buyEx, buyPrice);
      if (!amount) return;

      // ─── Verificar saldo coin na exchange de venda ────────────────────
      const hasCoin = await this.checkCoinBalance(sellEx, amount);
      if (!hasCoin) {
        console.warn(`[BALANCE] ${sellExName} não tem coin suficiente para vender ${amount}.`);
        return;
      }

      // ─── LEG 1: COMPRA ────────────────────────────────────────────────
      let buyFilled = false;
      let actualBuyPrice = buyPrice;
      let actualBuyAmount = amount;

      try {
        const buyOrder = await buyEx.createMarketBuyOrder(
          this.config.symbol,
          amount
        );
        if (buyOrder && buyOrder.id !== 'skipped' && buyOrder.amount > 0) {
          buyFilled = true;
          actualBuyPrice = buyOrder?.average ?? buyOrder?.price ?? buyPrice;
          actualBuyAmount = buyOrder.amount;
          console.log(`[BUY  ${buyExName}] Price: ${actualBuyPrice} | Amount: ${actualBuyAmount}`);
        } else {
          console.warn(`[BUY SKIPPED ${buyExName}] Order amount was 0 or skipped.`);
          return;
        }
      } catch (buyErr: any) {
        console.error(`[BUY ERROR ${buyExName}] ${buyErr?.message ?? buyErr}`);
        // Compra falhou — não há posição aberta, abortar sem risco
        return;
      }

      // ─── LEG 2: VENDA ─────────────────────────────────────────────────
      let sellFilled = false;
      let actualSellPrice = sellPrice;

      try {
        const sellOrder = await sellEx.createMarketSellOrder(
          this.config.symbol,
          actualBuyAmount
        );
        if (sellOrder && sellOrder.id !== 'skipped' && sellOrder.amount > 0) {
          sellFilled = true;
          actualSellPrice = sellOrder?.average ?? sellOrder?.price ?? sellPrice;
          console.log(`[SELL ${sellExName}] Price: ${actualSellPrice} | Amount: ${actualBuyAmount}`);
        } else {
          console.warn(`[SELL SKIPPED ${sellExName}] Order amount was 0 or skipped.`);
          // ─── RECUPERAÇÃO: venda falhada com posição aberta em buyEx ──────
          if (buyFilled) {
            console.warn(`[RECOVERY] Compra executada mas venda falhou/pulou. A tentar fechar posição em ${buyExName}...`);
            await this.emergencyClose(buyEx, buyExName, actualBuyAmount);
          }
          return;
        }
      } catch (sellErr: any) {
        console.error(`[SELL ERROR ${sellExName}] ${sellErr?.message ?? sellErr}`);

        // ─── RECUPERAÇÃO: venda falhada com posição aberta em buyEx ──────
        if (buyFilled) {
          console.warn(`[RECOVERY] Compra executada mas venda falhou. A tentar fechar posição em ${buyExName}...`);
          await this.emergencyClose(buyEx, buyExName, actualBuyAmount);
        }
        return;
      }

      // ─── Calcular P&L real ────────────────────────────────────────────
      if (buyFilled && sellFilled) {
        const grossPnl = (actualSellPrice - actualBuyPrice) * actualBuyAmount;
        const fees = (actualBuyPrice * this.FEE1 + actualSellPrice * this.FEE2) * actualBuyAmount;
        const netPnl = grossPnl - fees;

        this.totalTrades++;
        this.totalNetPnl += netPnl;
        if (netPnl > 0) this.winTrades++;

        const winRate = ((this.winTrades / this.totalTrades) * 100).toFixed(1);

        console.log(
          `[RESULT] Gross: $${grossPnl.toFixed(4)} | ` +
          `Fees: $${fees.toFixed(4)} | ` +
          `Net: $${netPnl.toFixed(4)} | ` +
          `Total PnL: $${this.totalNetPnl.toFixed(3)} | ` +
          `Win rate: ${winRate}% (${this.winTrades}/${this.totalTrades})`
        );
      }

    } catch (err: any) {
      console.error(`[ARBITRAGE ERROR] ${err?.message ?? err}`);
    }
  }

  // ─── HELPERS ─────────────────────────────────────────────────────────────

  /**
   * Calcula o amount a comprar com base no saldo disponível e RISK_PCT.
   * Retorna null se saldo insuficiente.
   */
  private async calcAmount(exchange: any, price: number): Promise<number | null> {
    try {
      const balance = await exchange.fetchBalance();
      const freeUsdt: number = balance?.free?.USDT ?? balance?.free?.usdt ?? 0;

      if (freeUsdt <= 0) {
        console.warn("[BALANCE] Saldo USDT zero.");
        return null;
      }

      const riskUsdt = freeUsdt * this.RISK_PCT;
      const amount = parseFloat((riskUsdt / price).toFixed(6));

      if (amount <= 0) {
        console.warn("[BALANCE] Amount calculado é zero.");
        return null;
      }

      return amount;
    } catch (err: any) {
      console.error(`[BALANCE ERROR] ${err?.message ?? err}`);
      return null;
    }
  }

  /**
   * Verifica se a exchange de venda tem coin suficiente.
   */
  private async checkCoinBalance(exchange: any, amount: number): Promise<boolean> {
    try {
      const balance = await exchange.fetchBalance();
      const symbol = this.config.symbol.split("/")[0]; // ex: "BTC" de "BTC/USDT"
      const freeCoin: number = balance?.free?.[symbol] ?? 0;
      return freeCoin >= amount;
    } catch {
      return false; // conservador: não executar se não conseguimos verificar
    }
  }

  /**
   * Venda de emergência quando leg de venda falha e existe posição aberta.
   * Tenta múltiplas vezes antes de desistir e logar o estado crítico.
   */
  private async emergencyClose(exchange: any, exchangeName: string, amount: number) {
    for (let attempt = 1; attempt <= this.MAX_RECOVERY_ATTEMPTS; attempt++) {
      try {
        await exchange.createMarketSellOrder(this.config.symbol, amount);
        console.log(`[RECOVERY OK] Posição fechada em ${exchangeName} (tentativa ${attempt})`);
        return;
      } catch (err: any) {
        console.error(
          `[RECOVERY FAIL] Tentativa ${attempt}/${this.MAX_RECOVERY_ATTEMPTS} ` +
          `em ${exchangeName}: ${err?.message ?? err}`
        );
        // Esperar antes de retentar (backoff simples)
        if (attempt < this.MAX_RECOVERY_ATTEMPTS) {
          await new Promise(r => setTimeout(r, 1000 * attempt));
        }
      }
    }
    console.error(
      `[CRITICAL] Não foi possível fechar posição em ${exchangeName} após ` +
      `${this.MAX_RECOVERY_ATTEMPTS} tentativas. INTERVENÇÃO MANUAL NECESSÁRIA.`
    );
  }
}
