import WebSocket from "ws";

export class MarketData {
  private ws: WebSocket;

  constructor(private symbol: string) {
    this.ws = new WebSocket(
      `wss://stream.binance.com:9443/ws/${symbol.toLowerCase()}@ticker`
    );
  }

  onMessage(callback: (data: any) => void) {
    this.ws.on("message", (msg) => {
      const data = JSON.parse(msg.toString());
      callback(data);
    });
  }
}
