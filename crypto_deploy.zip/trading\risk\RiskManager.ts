export class RiskManager {
  constructor(private config: any) {}

  canTrade(balance: number, amount: number) {
    const maxRisk = this.config.max_risk_per_trade || 0.02;

    return amount <= balance * maxRisk;
  }

  stopLoss(entry: number, current: number) {
    const loss = (current - entry) / entry;

    return loss < -this.config.stop_loss;
  }

  takeProfit(entry: number, current: number) {
    const profit = (current - entry) / entry;

    return profit > this.config.take_profit;
  }
}
