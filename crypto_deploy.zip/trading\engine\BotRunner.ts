import { StrategyFactory } from "./StrategyFactory";
import { RiskManager } from "../risk/RiskManager";
import { ExecutionEngine } from "../execution/ExecutionEngine";

export class BotRunner {
  private strategy: any;
  private risk: RiskManager;
  private execution: ExecutionEngine;
  private running = false;

  constructor(private engine: any, private config: any) {
    this.strategy = StrategyFactory.create(config, engine);
    this.risk = new RiskManager(config);
    this.execution = new ExecutionEngine(engine["exchange"]);
  }

  async start() {
    this.running = true;

    await this.strategy.execute();

    while (this.running) {
      try {
        await this.strategy.onTick();
      } catch (e) {
        console.error("Bot error:", e);
      }

      await new Promise((r) => setTimeout(r, 2000));
    }
  }

  stop() {
    this.running = false;
  }
}
