import { GridStrategy } from "../strategies/GridStrategy";
import { TrendStrategy } from "../strategies/TrendStrategy";
import { ScalpingStrategy } from "../strategies/ScalpingStrategy";
import { MarketMakingStrategy } from "../strategies/MarketMakingStrategy";
import { ArbitrageStrategy } from "../strategies/ArbitrageStrategy";
import { AIAdaptiveStrategy } from "../strategies/AIAdaptiveStrategy";
import { LoopStrategy } from "../strategies/LoopStrategy";

export class StrategyFactory {
  static create(config: any, engine: any) {
    const exchange = engine["exchange"];
    const secondaryExchange = engine["secondaryExchange"];

    switch (config.strategy) {
      case "GRID":
        return new GridStrategy(config, exchange);
      case "TREND":
        return new TrendStrategy(config, exchange);
      case "SCALPING":
        return new ScalpingStrategy(config, exchange);
      case "MARKET_MAKING":
        return new MarketMakingStrategy(config, exchange);
      case "ARBITRAGE":
        return new ArbitrageStrategy(exchange, secondaryExchange, config);
      case "AI_ADAPTIVE":
        return new AIAdaptiveStrategy(config, exchange);
      case "LOOP":
        return new LoopStrategy(config, exchange);
      default:
        return new GridStrategy(config, exchange);
    }
  }
}
