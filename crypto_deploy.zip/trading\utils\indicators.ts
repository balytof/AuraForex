export function SMA(prices: number[], period: number) {
  return (
    prices.slice(-period).reduce((a, b) => a + b, 0) /
    period
  );
}

export function RSI(prices: number[], period = 14) {
  let gains = 0;
  let losses = 0;

  for (let i = 1; i < period; i++) {
    const diff = prices[i] - prices[i - 1];
    if (diff > 0) gains += diff;
    else losses -= diff;
  }

  const rs = gains / losses;
  return 100 - 100 / (1 + rs);
}
