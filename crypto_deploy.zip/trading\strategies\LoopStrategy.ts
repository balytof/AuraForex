import { BaseStrategy } from "./BaseStrategy";

/**
 * LoopStrategy — Grid Trading melhorado
 *
 * Conceito: comprar em quedas, vender em altas, repetir.
 * Lucrativo em mercados laterais / com oscilação regular.
 *
 * Melhorias sobre o original:
 *  - Grid dinâmico baseado em ATR (spread cobre sempre os fees)
 *  - Reancoragem automática quando preço se afasta do centro
 *  - Stop loss global (% abaixo do preço de entrada)
 *  - Position sizing dinâmico (% do saldo)
 *  - Try/catch em todas as ordens
 *  - Verificação de saldo antes de comprar
 *  - Fee awareness (spread mínimo garantido)
 *  - Logging com P&L acumulado e win rate
 */

type GridState = "WAITING_BUY" | "WAITING_SELL";

export class LoopStrategy extends BaseStrategy {

  // ─── Estado do grid ───────────────────────────────────────────────────────
  public state: GridState = "WAITING_BUY";
  public buyPrice: number = 0;
  public sellPrice: number = 0;
  public anchorPrice: number = 0;    // preço central do grid atual
  public entryPrice: number = 0;     // preço real da última compra
  public currentAmount: number = 0;  // quantidade comprada

  // ─── Histórico de preços para ATR ─────────────────────────────────────────
  public prices: number[] = [];

  // ─── Estatísticas ─────────────────────────────────────────────────────────
  public totalCycles: number = 0;
  public winCycles: number = 0;
  public totalPnl: number = 0;

  // ─── Config com defaults ──────────────────────────────────────────────────
  // Todos configuráveis via this.config, com fallbacks sensatos

  /** % do saldo usado por compra */
  private readonly RISK_PCT: number = this.config.risk_pct ?? 0.05; // 5%

  /** % de spread mínimo acima dos fees. Ex: 0.003 = 0.3% */
  private readonly MIN_SPREAD_PCT: number = this.config.min_spread_pct ?? 0.004;

  /** Multiplicador do ATR para definir o spread do grid */
  private readonly ATR_MULTIPLIER: number = this.config.atr_multiplier ?? 1.5;

  /** % de desvio do anchor que dispara reancoragem */
  private readonly REANCHOR_PCT: number = this.config.reanchor_pct ?? 0.05; // 5%

  /** % de queda abaixo do preço de entrada que aciona stop global */
  private readonly STOP_LOSS_PCT: number = this.config.stop_loss_pct ?? 0.07; // 7%

  /** Fee da exchange (round-trip: compra + venda) */
  private readonly FEE_PCT: number = this.config.fee_pct ?? 0.002; // 0.2% total

  /** Período do ATR */
  private readonly ATR_PERIOD: number = this.config.atr_period ?? 14;

  /** Mínimo de preços antes de operar */
  private readonly MIN_PRICES: number = this.ATR_PERIOD + 1;

  async execute() {
    console.log("=== LoopStrategy (Grid Trading) started ===");
    console.log(`Symbol       : ${this.symbol}`);
    console.log(`Risk/trade   : ${(this.RISK_PCT * 100).toFixed(1)}%`);
    console.log(`Min spread   : ${(this.MIN_SPREAD_PCT * 100).toFixed(2)}%`);
    console.log(`ATR mult     : ${this.ATR_MULTIPLIER}x`);
    console.log(`Stop loss    : ${(this.STOP_LOSS_PCT * 100).toFixed(1)}% below entry`);
    console.log(`Reanchor at  : ±${(this.REANCHOR_PCT * 100).toFixed(1)}% from center`);
    console.log(`Exchange fee : ${(this.FEE_PCT * 100).toFixed(2)}% round-trip`);
  }

  async onTick() {
    try {
      // ─── 1. Fetch preço atual ──────────────────────────────────────────
      const ticker = await this.exchange.fetchTicker(this.symbol);
      const price: number = ticker.last;

      if (!price || price <= 0) {
        console.warn("[TICK] Preço inválido, a saltar tick.");
        return;
      }

      // ─── 2. Acumular histórico (janela 100) ───────────────────────────
      this.prices.push(price);
      if (this.prices.length > 100) this.prices.shift();

      if (this.prices.length < this.MIN_PRICES) {
        console.log(`[WARMUP] ${this.prices.length}/${this.MIN_PRICES} preços acumulados...`);
        return;
      }

      // ─── 3. Primeiro tick: definir grid inicial ───────────────────────
      if (this.anchorPrice === 0) {
        await this.buildGrid(price);
      }

      // ─── 4. Stop loss global (quando temos posição) ───────────────────
      if (this.state === "WAITING_SELL" && this.entryPrice > 0) {
        const drawdown = (price - this.entryPrice) / this.entryPrice;
        if (drawdown <= -this.STOP_LOSS_PCT) {
          console.log(`[STOP LOSS] Preço ${price} caiu ${(drawdown * 100).toFixed(2)}% abaixo da entrada ${this.entryPrice}`);
          await this.emergencySell(price);
          return;
        }
      }

      // ─── 5. Reancoragem se preço saiu do range do grid ────────────────
      const deviation = Math.abs(price - this.anchorPrice) / this.anchorPrice;
      if (deviation >= this.REANCHOR_PCT && this.state === "WAITING_BUY") {
        console.log(`[REANCHOR] Preço ${price} desviou ${(deviation * 100).toFixed(1)}% do centro ${this.anchorPrice.toFixed(4)}`);
        await this.buildGrid(price);
      }

      // ─── 6. Lógica de compra ──────────────────────────────────────────
      if (this.state === "WAITING_BUY" && price <= this.buyPrice) {
        await this.executeBuy(price);
        return;
      }

      // ─── 7. Lógica de venda ───────────────────────────────────────────
      if (this.state === "WAITING_SELL" && price >= this.sellPrice) {
        await this.executeSell(price);
        return;
      }

    } catch (err: any) {
      console.error(`[TICK ERROR] ${err?.message ?? err}`);
    }
  }

  // ─── GRID ─────────────────────────────────────────────────────────────────

  /**
   * Calcula e define os níveis de compra e venda com base no ATR atual.
   * O spread é sempre >= MIN_SPREAD_PCT + FEE_PCT para garantir lucro.
   */
  private async buildGrid(centerPrice: number) {
    const atr = this.ATR(this.prices, this.ATR_PERIOD);
    const atrSpread = atr / centerPrice; // ATR como % do preço

    // Spread efectivo: max entre ATR*mult e mínimo definido por config
    const minRequired = this.MIN_SPREAD_PCT + this.FEE_PCT;
    const spread = Math.max(atrSpread * this.ATR_MULTIPLIER, minRequired);

    this.anchorPrice = centerPrice;
    this.buyPrice = centerPrice * (1 - spread / 2);
    this.sellPrice = centerPrice * (1 + spread / 2);

    const spreadPct = (this.sellPrice - this.buyPrice) / this.buyPrice;
    const netPct = spreadPct - this.FEE_PCT;

    console.log(
      `[GRID] Anchor: ${centerPrice.toFixed(4)} | ` +
      `Buy: ${this.buyPrice.toFixed(4)} | ` +
      `Sell: ${this.sellPrice.toFixed(4)} | ` +
      `Spread: ${(spreadPct * 100).toFixed(2)}% | ` +
      `Net/ciclo: ${(netPct * 100).toFixed(2)}%`
    );
  }

  // ─── ORDENS ───────────────────────────────────────────────────────────────

  private async executeBuy(price: number) {
    try {
      // Verificar saldo disponível
      const balance = await this.exchange.fetchBalance();
      const freeUsdt: number =
        balance?.free?.USDT ?? balance?.free?.usdt ?? 0;

      if (freeUsdt <= 0) {
        console.warn("[BUY] Saldo USDT insuficiente.");
        return;
      }

      const riskAmount = freeUsdt * this.RISK_PCT;
      const amount = parseFloat((riskAmount / price).toFixed(6));

      if (amount <= 0) {
        console.warn("[BUY] Amount calculado é zero.");
        return;
      }

      const buyOrder = await this.exchange.createMarketBuyOrder(this.symbol, amount);

      if (buyOrder && buyOrder.id !== 'skipped' && buyOrder.amount > 0) {
        this.state = "WAITING_SELL";
        this.entryPrice = price;
        this.currentAmount = buyOrder.amount;

        console.log(
          `[BUY]  Price: ${price.toFixed(4)} | ` +
          `Amount: ${this.currentAmount} | ` +
          `Cost: $${(this.currentAmount * price).toFixed(2)} | ` +
          `Sell target: ${this.sellPrice.toFixed(4)}`
        );
      } else {
        console.warn("[BUY] Order skipped or failed (amount 0).");
      }

    } catch (err: any) {
      console.error(`[BUY ERROR] ${err?.message ?? err}`);
      // Estado não muda — tenta novamente no próximo tick
    }
  }

  private async executeSell(price: number) {
    try {
      if (this.currentAmount <= 0) {
        console.warn("[SELL] Nenhuma quantidade para vender.");
        this.state = "WAITING_BUY";
        return;
      }

      const sellOrder = await this.exchange.createMarketSellOrder(this.symbol, this.currentAmount);

      if (sellOrder && sellOrder.id !== 'skipped' && sellOrder.amount > 0) {
        const actualAmount = sellOrder.amount;
        // Calcular P&L do ciclo
        const grossPnl = (price - this.entryPrice) * actualAmount;
        const feesCost = (this.entryPrice + price) * actualAmount * (this.FEE_PCT / 2);
        const netPnl = grossPnl - feesCost;
        this.totalPnl += netPnl;
        this.totalCycles++;
        if (netPnl > 0) this.winCycles++;

        const winRate = ((this.winCycles / this.totalCycles) * 100).toFixed(1);

        console.log(
          `[SELL] Price: ${price.toFixed(4)} | ` +
          `Entry: ${this.entryPrice.toFixed(4)} | ` +
          `Net PnL: $${netPnl.toFixed(3)} | ` +
          `Total PnL: $${this.totalPnl.toFixed(2)} | ` +
          `Win rate: ${winRate}% (${this.winCycles}/${this.totalCycles})`
        );

        // Reset estado para próximo ciclo
        this.state = "WAITING_BUY";
        this.entryPrice = 0;
        this.currentAmount = 0;

        // Reconstruir grid a partir do novo preço após ciclo completo
        await this.buildGrid(price);
      } else {
        console.warn("[SELL] Order skipped or failed (amount 0). Resetting state to WAITING_BUY.");
        this.state = "WAITING_BUY";
        this.currentAmount = 0;
      }

    } catch (err: any) {
      console.error(`[SELL ERROR] ${err?.message ?? err}`);
      // Estado de emergência: resetar para não ficar bloqueado
      this.state = "WAITING_BUY";
    }
  }

  /** Venda de emergência por stop loss global */
  private async emergencySell(price: number) {
    try {
      if (this.currentAmount > 0) {
        await this.exchange.createMarketSellOrder(this.symbol, this.currentAmount);
      }

      const pnl = (price - this.entryPrice) * this.currentAmount;
      this.totalPnl += pnl;
      this.totalCycles++;
      // stop loss = derrota, não conta como win

      console.log(
        `[EMERGENCY SELL] Price: ${price.toFixed(4)} | ` +
        `PnL: $${pnl.toFixed(2)} | ` +
        `Total PnL: $${this.totalPnl.toFixed(2)}`
      );

      this.state = "WAITING_BUY";
      this.entryPrice = 0;
      this.currentAmount = 0;

      // Reconstruir grid no nível actual
      await this.buildGrid(price);

    } catch (err: any) {
      console.error(`[EMERGENCY SELL ERROR] ${err?.message ?? err}`);
      this.state = "WAITING_BUY";
      this.currentAmount = 0;
    }
  }

  // ─── INDICADORES ─────────────────────────────────────────────────────────

  /**
   * ATR simplificado: média das diferenças absolutas entre ticks consecutivos.
   * Proxy válido quando não temos high/low separados.
   */
  private ATR(prices: number[], period: number): number {
    if (prices.length < period + 1) return prices[prices.length - 1] * 0.01; // fallback 1%
    const slice = prices.slice(-(period + 1));
    let sum = 0;
    for (let i = 1; i < slice.length; i++) {
      sum += Math.abs(slice[i] - slice[i - 1]);
    }
    return sum / period;
  }
}
