export class PortfolioManager {
  private positions: any = {};

  updatePosition(symbol: string, amount: number) {
    this.positions[symbol] =
      (this.positions[symbol] || 0) + amount;
  }

  getPosition(symbol: string) {
    return this.positions[symbol] || 0;
  }
}
