import { BaseStrategy } from "./BaseStrategy";

export class ScalpingStrategy extends BaseStrategy {
  async execute() {}

  async onTick() {
    const ob = await this.exchange.fetchOrderBook(this.symbol);

    const bid = ob.bids[0][0];
    const ask = ob.asks[0][0];

    const spread = ask - bid;

    if (spread > this.config.min_spread) {
      const buyOrder = await this.exchange.createLimitBuyOrder(
        this.symbol,
        this.config.amount,
        bid
      );

      if (buyOrder && buyOrder.id !== 'skipped' && buyOrder.amount > 0) {
        await this.exchange.createLimitSellOrder(
          this.symbol,
          buyOrder.amount,
          ask
        );
      }
    }
  }
}
