import { BaseStrategy } from "./BaseStrategy";

/**
 * MarketMakingStrategy — Market Making profissional
 *
 * Conceito: colocar ordens limit de compra e venda em torno do mid-price,
 * capturando o spread como lucro quando ambas executam.
 *
 * Correções críticas sobre o original:
 *  - Cancelamento de todas as ordens antes de cada novo ciclo
 *  - Spread dinâmico baseado em ATR (cobre fees + volatilidade)
 *  - Quote skewing por inventory (reequilibra posição automaticamente)
 *  - Limite de inventory com market order de emergência
 *  - Circuit breaker anti adverse selection (pausa em alta volatilidade)
 *  - postOnly=true para garantir fee de maker
 *  - Position sizing dinâmico (% do saldo)
 *  - Try/catch completo com recuperação de erros
 *  - Logging com P&L estimado e estatísticas de inventory
 */
export class MarketMakingStrategy extends BaseStrategy {

  // ─── Estado de ordens ativas ──────────────────────────────────────────────
  public activeBuyOrderId:  string | null = null;
  public activeSellOrderId: string | null = null;

  // ─── Inventory tracking ───────────────────────────────────────────────────
  public inventoryCoin: number = 0;    // quantidade de coin em carteira
  public inventoryCost: number = 0;    // custo médio ponderado (USDT)

  // ─── Circuit breaker ─────────────────────────────────────────────────────
  public pauseTicks: number = 0;
  public lastMidPrice: number = 0;
  public priceHistory: number[] = [];

  // ─── Estatísticas ─────────────────────────────────────────────────────────
  public totalBuysFilled:  number = 0;
  public totalSellsFilled: number = 0;
  public totalFeesPaid:    number = 0;
  public estimatedPnl:     number = 0;

  // ─── Config com defaults ──────────────────────────────────────────────────

  /** Fee de maker (postOnly). Ex: Binance = 0.0001 com BNB, standard = 0.001 */
  private readonly MAKER_FEE: number = this.config.maker_fee ?? 0.001;

  /** Spread mínimo em % (deve cobrir 2x maker fee + margem) */
  private readonly MIN_SPREAD_PCT: number = this.config.min_spread_pct ?? 0.003;

  /** Multiplicador de ATR para o spread */
  private readonly ATR_MULT: number = this.config.atr_mult ?? 1.0;

  /** Período do ATR */
  private readonly ATR_PERIOD: number = this.config.atr_period ?? 20;

  /** % do saldo USDT usado por ordem de compra */
  private readonly RISK_PCT: number = this.config.risk_pct ?? 0.05; // 5%

  /** Inventory máximo em coin (acima disto → emergência) */
  private readonly MAX_INVENTORY: number = this.config.max_inventory ?? 10;

  /** Inventory target (coin ideal a manter) */
  private readonly TARGET_INVENTORY: number = this.config.target_inventory ?? 5;

  /** Fator de skewing do mid-price por desvio do inventory (0–1) */
  private readonly SKEW_FACTOR: number = this.config.skew_factor ?? 0.3;

  /** % de movimento de preço que ativa circuit breaker */
  private readonly CIRCUIT_BREAKER_PCT: number = this.config.circuit_breaker_pct ?? 0.015; // 1.5%

  /** Número de ticks de pausa quando circuit breaker ativa */
  private readonly PAUSE_TICKS: number = this.config.pause_ticks ?? 5;

  /** Janela de preços para detetar movimento direcional (ticks) */
  private readonly VOLATILITY_WINDOW: number = this.config.volatility_window ?? 10;

  async execute() {
    console.log("=== MarketMakingStrategy started ===");
    console.log(`Symbol          : ${this.symbol}`);
    console.log(`Maker fee       : ${(this.MAKER_FEE * 100).toFixed(3)}%`);
    console.log(`Min spread      : ${(this.MIN_SPREAD_PCT * 100).toFixed(3)}%`);
    console.log(`ATR multiplier  : ${this.ATR_MULT}x`);
    console.log(`Risk per order  : ${(this.RISK_PCT * 100).toFixed(1)}%`);
    console.log(`Max inventory   : ${this.MAX_INVENTORY} coin`);
    console.log(`Target inventory: ${this.TARGET_INVENTORY} coin`);
    console.log(`Circuit breaker : ${(this.CIRCUIT_BREAKER_PCT * 100).toFixed(1)}% move`);

    // Sincronizar inventory inicial com saldo real
    await this.syncInventory();
  }

  async onTick() {
    try {
      // ─── 1. Gerir circuit breaker ────────────────────────────────────
      if (this.pauseTicks > 0) {
        this.pauseTicks--;
        console.log(`[PAUSE] Circuit breaker ativo. Ticks restantes: ${this.pauseTicks}`);
        await this.cancelAllOrders();
        return;
      }

      // ─── 2. Fetch orderbook ───────────────────────────────────────────
      const ob = await this.exchange.fetchOrderBook(this.symbol, 5);
      const bid = ob.bids?.[0]?.[0];
      const ask = ob.asks?.[0]?.[0];

      if (!bid || !ask || bid <= 0 || ask <= 0) {
        console.warn("[TICK] Orderbook inválido, a saltar.");
        return;
      }

      const rawMid = (bid + ask) / 2;

      // ─── 3. Acumular histórico de preços ─────────────────────────────
      this.priceHistory.push(rawMid);
      if (this.priceHistory.length > 100) this.priceHistory.shift();

      // ─── 4. Detetar movimento direcional forte (adverse selection) ────
      if (this.priceHistory.length >= this.VOLATILITY_WINDOW && this.lastMidPrice > 0) {
        const windowStart = this.priceHistory[this.priceHistory.length - this.VOLATILITY_WINDOW];
        const recentMove = Math.abs(rawMid - windowStart) / windowStart;

        if (recentMove >= this.CIRCUIT_BREAKER_PCT) {
          console.warn(
            `[CIRCUIT BREAKER] Movimento de ${(recentMove * 100).toFixed(2)}% detetado. ` +
            `A pausar por ${this.PAUSE_TICKS} ticks.`
          );
          this.pauseTicks = this.PAUSE_TICKS;
          await this.cancelAllOrders();
          this.lastMidPrice = rawMid;
          return;
        }
      }
      this.lastMidPrice = rawMid;

      // ─── 5. Verificar inventory e gerir emergência ────────────────────
      await this.syncInventory();

      if (this.inventoryCoin > this.MAX_INVENTORY) {
        console.warn(
          `[INVENTORY EMERGENCY] ${this.inventoryCoin.toFixed(4)} coin > max ${this.MAX_INVENTORY}. ` +
          `A executar market sell de reequilíbrio.`
        );
        await this.cancelAllOrders();
        await this.rebalanceInventory(rawMid);
        return;
      }

      // ─── 6. Calcular spread dinâmico via ATR ─────────────────────────
      const atr = this.calcATR(this.priceHistory, this.ATR_PERIOD);
      const atrSpreadPct = (atr / rawMid) * this.ATR_MULT;
      const halfSpread = Math.max(atrSpreadPct / 2, this.MIN_SPREAD_PCT / 2);

      // ─── 7. Quote skewing por inventory ──────────────────────────────
      // Se temos mais coin que o target → skew para baixo (incentivar vendas)
      // Se temos menos coin que o target → skew para cima (incentivar compras)
      const inventoryDelta = this.inventoryCoin - this.TARGET_INVENTORY;
      const skew = inventoryDelta * this.SKEW_FACTOR * halfSpread;
      const mid = rawMid - skew; // mid ajustado pelo inventory

      // ─── 8. Calcular preços de ordem ─────────────────────────────────
      const buyPrice  = parseFloat((mid - halfSpread * rawMid).toFixed(8));
      const sellPrice = parseFloat((mid + halfSpread * rawMid).toFixed(8));

      // Validação: compra deve ser sempre abaixo da venda
      if (buyPrice >= sellPrice || buyPrice <= 0 || sellPrice <= 0) {
        console.warn(`[PRICING] Preços inválidos: buy=${buyPrice} sell=${sellPrice}. A saltar.`);
        return;
      }

      // ─── 9. Calcular amount ───────────────────────────────────────────
      const amount = await this.calcAmount(buyPrice);
      if (!amount) return;

      // ─── 10. Cancelar ordens antigas ─────────────────────────────────
      await this.cancelAllOrders();

      // ─── 11. Colocar novas ordens (postOnly = maker fee garantida) ────
      await this.placeBuyOrder(buyPrice, amount);
      await this.placeSellOrder(sellPrice, amount);

      console.log(
        `[QUOTES] Mid: ${rawMid.toFixed(4)} | Skew: ${(-skew).toFixed(4)} | ` +
        `Buy: ${buyPrice.toFixed(4)} | Sell: ${sellPrice.toFixed(4)} | ` +
        `Spread: ${(halfSpread * 2 * 100).toFixed(3)}% | ` +
        `Inventory: ${this.inventoryCoin.toFixed(4)} coin | ` +
        `Est. PnL: $${this.estimatedPnl.toFixed(3)}`
      );

    } catch (err: any) {
      console.error(`[TICK ERROR] ${err?.message ?? err}`);
      // Em caso de erro inesperado, cancelar tudo para evitar estado inconsistente
      await this.cancelAllOrders().catch(() => {});
    }
  }

  // ─── ORDENS ───────────────────────────────────────────────────────────────

  private async placeBuyOrder(price: number, amount: number) {
    try {
      const order = await this.exchange.createLimitBuyOrder(
        this.symbol,
        amount,
        price,
        { postOnly: true } // garante fee de maker; rejeita se cruzasse o livro
      );
      
      if (order && order.id !== 'skipped' && order.amount > 0) {
        this.activeBuyOrderId = order.id;
        // Callback: registar fill se ordem executar imediatamente (raro com postOnly)
        if (order.status === "closed") {
          this.onBuyFilled(price, order.amount);
        }
      } else {
        this.activeBuyOrderId = null;
      }
    } catch (err: any) {
      // postOnly rejeita se preço cruzaria o livro — é normal, não é erro crítico
      if (err?.message?.includes("postOnly") || err?.message?.includes("post only")) {
        console.log(`[BUY] Ordem rejeitada (cruzaria livro) @ ${price} — normal com postOnly.`);
      } else {
        console.error(`[BUY ORDER ERROR] ${err?.message ?? err}`);
      }
      this.activeBuyOrderId = null;
    }
  }

  private async placeSellOrder(price: number, amount: number) {
    try {
      // Verificar saldo de coin para a venda
      const coinBalance = await this.getCoinBalance();
      if (coinBalance < amount) {
        console.warn(`[SELL] Saldo de coin insuficiente: ${coinBalance.toFixed(4)} < ${amount}`);
        return;
      }

      const order = await this.exchange.createLimitSellOrder(
        this.symbol,
        amount,
        price,
        { postOnly: true }
      );
      
      if (order && order.id !== 'skipped' && order.amount > 0) {
        this.activeSellOrderId = order.id;
        if (order.status === "closed") {
          this.onSellFilled(price, order.amount);
        }
      } else {
        this.activeSellOrderId = null;
      }
    } catch (err: any) {
      if (err?.message?.includes("postOnly") || err?.message?.includes("post only")) {
        console.log(`[SELL] Ordem rejeitada (cruzaria livro) @ ${price} — normal com postOnly.`);
      } else {
        console.error(`[SELL ORDER ERROR] ${err?.message ?? err}`);
      }
      this.activeSellOrderId = null;
    }
  }

  private async cancelAllOrders() {
    const toCancel = [this.activeBuyOrderId, this.activeSellOrderId].filter(Boolean);

    for (const orderId of toCancel) {
      try {
        await this.exchange.cancelOrder(orderId!, this.symbol);
      } catch (err: any) {
        // Pode já ter sido executada — não é erro crítico
        if (!err?.message?.includes("not found") && !err?.message?.includes("already")) {
          console.warn(`[CANCEL] Erro ao cancelar ${orderId}: ${err?.message ?? err}`);
        }
      }
    }

    this.activeBuyOrderId  = null;
    this.activeSellOrderId = null;
  }

  // ─── INVENTORY ────────────────────────────────────────────────────────────

  private async syncInventory() {
    try {
      const symbol = this.symbol.split("/")[0]; // "BTC" de "BTC/USDT"
      const balance = await this.exchange.fetchBalance();
      this.inventoryCoin = balance?.free?.[symbol] ?? 0;
    } catch {
      // Não crítico — usa valor anterior
    }
  }

  private async getCoinBalance(): Promise<number> {
    try {
      const symbol = this.symbol.split("/")[0];
      const balance = await this.exchange.fetchBalance();
      return balance?.free?.[symbol] ?? 0;
    } catch {
      return 0;
    }
  }

  /** Market order para reequilibrar inventory de emergência */
  private async rebalanceInventory(price: number) {
    const excess = this.inventoryCoin - this.TARGET_INVENTORY;
    if (excess <= 0) return;

    const sellAmount = parseFloat(excess.toFixed(6));
    try {
      await this.exchange.createMarketSellOrder(this.symbol, sellAmount);
      console.log(`[REBALANCE] Vendeu ${sellAmount} coin @ ~${price} para reequilibrar inventory.`);
      this.inventoryCoin -= sellAmount;
    } catch (err: any) {
      console.error(`[REBALANCE ERROR] ${err?.message ?? err}`);
    }
  }

  // ─── CALLBACKS DE FILL ────────────────────────────────────────────────────

  private onBuyFilled(price: number, amount: number) {
    this.totalBuysFilled++;
    this.inventoryCoin += amount;
    const cost = price * amount;
    this.inventoryCost += cost;
    const fee = cost * this.MAKER_FEE;
    this.totalFeesPaid += fee;
    console.log(`[FILL BUY]  @ ${price} | Amount: ${amount} | Fee: $${fee.toFixed(4)}`);
  }

  private onSellFilled(price: number, amount: number) {
    this.totalSellsFilled++;
    this.inventoryCoin -= amount;
    const revenue = price * amount;
    const fee = revenue * this.MAKER_FEE;
    this.totalFeesPaid += fee;

    // Estimar P&L do ciclo (venda - custo médio - fees)
    const avgCost = this.totalBuysFilled > 0
      ? this.inventoryCost / this.totalBuysFilled
      : price;
    const cyclePnl = (price - avgCost) * amount - fee;
    this.estimatedPnl += cyclePnl;

    console.log(
      `[FILL SELL] @ ${price} | Amount: ${amount} | ` +
      `Fee: $${fee.toFixed(4)} | Cycle PnL est.: $${cyclePnl.toFixed(4)} | ` +
      `Total est. PnL: $${this.estimatedPnl.toFixed(3)}`
    );
  }

  // ─── HELPERS ──────────────────────────────────────────────────────────────

  private async calcAmount(buyPrice: number): Promise<number | null> {
    try {
      const balance = await this.exchange.fetchBalance();
      const freeUsdt: number = balance?.free?.USDT ?? balance?.free?.usdt ?? 0;

      if (freeUsdt <= 0) {
        console.warn("[BALANCE] Saldo USDT zero.");
        return null;
      }

      const riskUsdt = freeUsdt * this.RISK_PCT;
      const amount = parseFloat((riskUsdt / buyPrice).toFixed(6));
      return amount > 0 ? amount : null;
    } catch (err: any) {
      console.error(`[BALANCE ERROR] ${err?.message ?? err}`);
      return null;
    }
  }

  /**
   * ATR: média das diferenças absolutas entre preços consecutivos.
   */
  private calcATR(prices: number[], period: number): number {
    if (prices.length < period + 1) {
      // Fallback: 0.5% do último preço
      return (prices[prices.length - 1] ?? 100) * 0.005;
    }
    const slice = prices.slice(-(period + 1));
    let sum = 0;
    for (let i = 1; i < slice.length; i++) {
      sum += Math.abs(slice[i] - slice[i - 1]);
    }
    return sum / period;
  }
}
