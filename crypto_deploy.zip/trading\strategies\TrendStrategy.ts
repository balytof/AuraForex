import { BaseStrategy } from "./BaseStrategy";

export class TrendStrategy extends BaseStrategy {
  public prices: number[] = [];
  public position: "NONE" | "LONG" = "NONE";
  public entryPrice: number = 0;
  public currentAmount: number = 0;

  async execute() {}

  async onTick() {
    const ticker = await this.exchange.fetchTicker(this.symbol);
    const price = ticker.last;

    this.prices.push(price);

    if (this.prices.length < 50) return;

    const maShort =
      this.prices.slice(-10).reduce((a, b) => a + b) / 10;

    const maLong =
      this.prices.slice(-50).reduce((a, b) => a + b) / 50;

    if (maShort > maLong && this.position !== "LONG") {
      const order = await this.exchange.createMarketBuyOrder(
        this.symbol,
        this.config.amount
      );
      if (order && order.id !== 'skipped' && order.amount > 0) {
        this.position = "LONG";
        this.entryPrice = order.price;
        this.currentAmount = order.amount;
      }
    }

    if (maShort < maLong && this.position === "LONG") {
      const order = await this.exchange.createMarketSellOrder(
        this.symbol,
        this.currentAmount || this.config.amount
      );
      if (order && order.id !== 'skipped' && order.amount > 0) {
        this.position = "NONE";
        this.entryPrice = 0;
        this.currentAmount = 0;
      } else if (order && order.id === 'skipped') {
        // If sell skipped, we might have lost track of balance or it's too small
        this.position = "NONE";
        this.entryPrice = 0;
        this.currentAmount = 0;
      }
    }
  }
}
