export class Logger {
  static log(message: string) {
    console.log(`[BOT] ${message}`);
  }

  static error(message: string) {
    console.error(`[ERROR] ${message}`);
  }
}
