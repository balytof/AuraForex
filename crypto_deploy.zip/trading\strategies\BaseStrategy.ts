export abstract class BaseStrategy {
  protected exchange: any;
  protected config: any;
  protected symbol: string;

  constructor(config: any, exchange: any) {
    this.config = config;
    this.exchange = exchange;
    this.symbol = config.symbol;
  }

  abstract execute(): Promise<void>;
  abstract onTick(): Promise<void>;
}
